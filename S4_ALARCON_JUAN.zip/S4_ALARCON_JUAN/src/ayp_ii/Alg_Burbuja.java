package ayp_ii;
import java.util.ArrayList;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Alg_Burbuja {

	public static void main(String[] args) {
		int cont=0,n=0;
		double order=0, num_prom=0,den_prom=0,promedio=0;
		boolean flag = false;
		 Scanner scanner = new Scanner(System.in);
		 ArrayList<String> dataLine = new ArrayList<String>(); 
         while (scanner.hasNextLine() ) {
             String line = scanner.nextLine();
             Scanner lineScanner = new Scanner(line);
             if (flag==false) {
            	 n=Integer.parseInt(line);
            	 flag=true;
             }
             lineScanner.useDelimiter("/n");
             while (lineScanner.hasNext()) {
                 String part = lineScanner.next();
                 dataLine.add(part);
                 cont=cont+1;
            	 if(cont>n) {
                	 break;
                 }
             }
        	 if(cont>n) {
            	 break;
             }
             lineScanner.close();
         }
         for(int h =0; h<n;h++) { 
        	String[] arrayData = dataLine.get(h+1).split(" ");	
        	double data_float[] = new double[arrayData.length];
			for (int i = 0; i < arrayData.length; i++) {
				data_float[i] = Float.parseFloat(arrayData[i]);    
			}
			//Empleo Metodo Burbujas
		    for(int i=0;i<(arrayData.length-1);i++) {
		    	for(int j=0; j<(arrayData.length-1);j++) {
		    		if(data_float[j]>data_float[j+1]) {
		    			if(order == data_float[j]) { // Evaluo cuantos numeros realizan intercambios
		    				order=data_float[j];
		    				den_prom=den_prom+1;
		    			}
		    			order=data_float[j];
		    			data_float[j]= data_float[j+1];
		    			data_float[j+1]=order;
		    			num_prom=num_prom+1;	// Evaluo cuantos intercambios repite el mismo numero y los almaceno.
		    		}
		    	}
		    }
		    System.out.println();
        }
        scanner.close();
         
	}
}
