package ayp_ii;
import java.util.ArrayList;
import java.util.Scanner;

public class Alg_Burbuja {

	public static void main(String[] args) {
		int cont=1,n=0;
		 boolean flag = false;
		 Scanner scanner = new Scanner(System.in);
		 ArrayList<String> dataLine = new ArrayList<String>(); 
        while (scanner.hasNextLine()&& cont != 0 ) {
            String line = scanner.nextLine();
            Scanner lineScanner = new Scanner(line);
            if (flag==false) {
           	 n=Integer.parseInt(line);
           	 flag=true;
            }
            lineScanner.useDelimiter("/n");
            while (lineScanner.hasNext()) {
                String part = lineScanner.next();
                dataLine.add(part);
                System.out.println(part+" ");
                cont=(dataLine.size()-n)-1;
            }
            lineScanner.close();
        }
        scanner.close();
	}
}
